/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.njc;
import java.util.ArrayList;



public class Carrito {
    ArrayList<Integer> Arr;
    private int IDCarrito;
    private int CedulaCliente;
   

    public Carrito() {
    }
    
    
public Carrito (int idcarrito, int cedulacliente){
    this.IDCarrito = idcarrito;
    this.CedulaCliente = cedulacliente;
    this.Arr = new ArrayList();
    
    
}
public int getIDCarrito() {
        return IDCarrito;
    }

    public void setIDCarrito(int IDCarrito) {
        this.IDCarrito = IDCarrito;
    }

    public int CedulaCliente() {
        return CedulaCliente;
    }

    public void setCedulaCliente(int CedulaCliente) {
        this.CedulaCliente = CedulaCliente;
    }

    
    public String toString2 (){
      String letrica = "";
    for(int i=0;i<this.Arr.size();i++){
        letrica = letrica + ";"+Arr.get(i);
    }
    return letrica;
    }
    public String toString() {
        return   IDCarrito + "," + CedulaCliente + ","+" Productos: "+this.toString2();
    }

    public ArrayList<Integer> getArr() {
        return Arr;
    }

    public void setArr(ArrayList<Integer> Arr) {
        this.Arr = Arr;
    }

}