/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.njc;

/**
 *
 * @author Nikolas
 */
public class Producto {
    int id;
    float precio;
    String Nombre;

    public Producto(int id, float precio, String Nombre) {
        this.id = id;
        this.precio = precio;
        this.Nombre = Nombre;
    }
    public Producto(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
}
