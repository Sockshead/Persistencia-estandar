/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.njc;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ProyectoNJC {
 
 //ArrayList<Clientes> ArregloClientes = new ArrayList<>();


    public static void main(String[] args) {
 PersistenciaCliente PCLIENTE = new PersistenciaCliente();
        
 ArrayList<Carrito> ArregloCarrito = new ArrayList<>();
 ArrayList<Clientes> ArregloClientes = PCLIENTE.CargarTodo();
       String texto = "";
        char opcion = '1';
        while ((opcion == '1') || (opcion == '2') || (opcion == '3') || (opcion == '4') || (opcion == '5') || (opcion == '6') || (opcion == '7')) {
            opcion = JOptionPane.showInputDialog("......................" + "\n INVENT PLUS 3000" + "\n......................"
                    + "\n 1-Mostrar Clientes" + "\n 2-Agregar Carrito" + "\n 3-Agregar Producto" + "\n 4-Ver Carrito"
                    ).charAt(0);
             String Variablita = ""; 
            switch (opcion) {
                case '1': for (int i = 0 ; i<ArregloClientes.size();i++){
                 
                 Variablita = Variablita  + "\n"+ArregloClientes.get(i).toString();
                }
                JOptionPane.showMessageDialog(null, Variablita);
                break;
                
                case '2': 
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog("Ingrese cédula"));
                    int x = 0;
                      Carrito carro1 = new Carrito(cedula,x);
                      ArregloCarrito.add(carro1);
                    x = 0+1;
                  
                    
            }
            
        }
    }
    
}

